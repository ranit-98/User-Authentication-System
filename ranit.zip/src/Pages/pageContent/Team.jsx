import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchTeamData } from '../../Redux/Slice/TeamSlice'

import {
    Card,
    CardContent,
    CardMedia,
    Typography,
    CardActionArea,
    Container,
    Grid,
  } from "@mui/material";
import Layout from '../../CommonComponents/Layout';
import HourglassLoader from '../../CommonComponents/HourglassLoading';
const Team = ({ withLayout = true }) => {
    const dispatch=useDispatch()
    const teamData=useSelector((state)=>state.team.data.TeamMember)
    const status=useSelector((state)=>state.team.status)
    useEffect(()=>{
        dispatch(fetchTeamData())
    },[dispatch])
    //console.log(teamData,status);
    const teamContent=( <>
      <Typography variant="h4" align="center" gutterBottom>
        Our Team
      </Typography>
      <Container maxWidth="xl" style={{ marginTop: "2rem" }}  sx={{
              width: { sm: '100%', md: '80%' },
              textAlign: { sm: 'left', md: 'center' },
            }}>
        <Grid container spacing={2}>
          {teamData?.map((member) => (
            <Grid item xs={12} sm={6} md={3} key={member._id}>
              <Card sx={{ maxWidth: 300 }}>
                <CardActionArea>
                  <CardMedia
                    component="img"
                    height="300"
                    image={`${process.env.REACT_APP_BASE_URL}/team/photo/${member._id}`}
                    alt={member.name}
                  />
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      {member.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {member.possession}
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </>)
  if (withLayout) {
    return (
      <Layout>
        {status==='loading' && <HourglassLoader />}
        {status==='idle' && teamContent}
      </Layout>
    );
  } else {
    return teamContent;
  }
}

export default Team
